package com.example.timer;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.media.MediaPlayer;
import android.os.Build;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.os.Handler;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.provider.Settings;
import android.text.format.DateUtils;
import android.view.InputDevice;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    public TextView time;
    public int tt;
    EditText text_input;

    MediaPlayer player;
    Vibrator vibrator;
    Context context=this;

    private static final int NOTIFY_ID = 101;
    private Handler handler;
    private NotificationManager notificationManager;
    private static String CHANNEL_ID = "Pizza channel";

    @Override
    protected void onCreate(Bundle savedInstanceState) {


        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        player=MediaPlayer.create(context, R.raw.alarm);
        vibrator=(Vibrator)getSystemService(Context.VIBRATOR_SERVICE);


        time = findViewById(R.id.timer_text);
        text_input = (EditText) findViewById(R.id.timer_input);
        handler = new Handler();
        notificationManager = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        NotificationChannel channel = null;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            channel = new NotificationChannel(CHANNEL_ID, "Main channel", notificationManager.IMPORTANCE_DEFAULT);
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            notificationManager.createNotificationChannel(channel);
        }

    }

    public void pizza_button(View view) {
        //tt = Integer.parseInt(text_input.getText().toString());
        Intent intent = new Intent(this, Pizza_Activity.class);
        startActivity(intent);

       /*new CountDownTimer(tt*1000, 1000) {
            @Override
            public void onTick(long l) {
                time.setText(DateUtils.formatElapsedTime(l / 1000));
            }

            @Override
            public void onFinish() {
                time.setText("-");
                NotificationCompat.Builder builder =
                        new NotificationCompat.Builder(Pizza_Activity.this, CHANNEL_ID)
                                .setContentTitle("Напоминание")
                                .setContentText("Пицца готова")
                                .setPriority(NotificationCompat.PRIORITY_DEFAULT);

                if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
                    NotificationChannel channel = new NotificationChannel(CHANNEL_ID, "name", NotificationManager.IMPORTANCE_HIGH);
                }
                NotificationManagerCompat notificationManager =
                        NotificationManagerCompat.from(Pizza_Activity.this);
                notificationManager.notify(NOTIFY_ID, builder.build());

            }
        }.start();*/
    }

    public void pelmen_button(View view) {
        Intent intent2 = new Intent(this, Pelmen_Activity.class);
        startActivity(intent2);
    }

    public void start_button(View view) {
        tt = Integer.parseInt(text_input.getText().toString());

        new CountDownTimer(tt * 1000, 1000) {
            @Override
            public void onTick(long l) {
                time.setText(DateUtils.formatElapsedTime(l / 1000));
            }

            @Override
            public void onFinish() {
                time.setText("-");

                handler.postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        Intent notificationIntent = new Intent(MainActivity.this, MainActivity.class);
                        PendingIntent contentIntent = PendingIntent.getActivity(MainActivity.this, 0, notificationIntent, 0);
                        NotificationCompat.Builder builder = new NotificationCompat.Builder(MainActivity.this, CHANNEL_ID)
                                .setSmallIcon(R.drawable.ic_launcher_background)
                                .setContentTitle("Ваша пыцца готова")
                                .setChannelId(CHANNEL_ID)
                                .setContentText("Ваша пыцца готова")
                                .setContentIntent(contentIntent)
                                .setPriority(NotificationCompat.PRIORITY_DEFAULT);
                        Notification notification = builder.build();
                        notification.defaults = Notification.DEFAULT_ALL;

                        notificationManager.notify(NOTIFY_ID, builder.build());

                        if (player.isPlaying()){
                            player.stop();
                            player.release();
                            player=MediaPlayer.create(context, R.raw.alarm);
                        }
                        player.start();
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                            long[] pattern = {0, 400, 0, 400};
                            // https://developer.alexanderklimov.ru/android/theory/vibrator.php?ysclid=leo3viql84681903614
                            vibrator.vibrate(VibrationEffect.createWaveform(pattern,-1));
                        }else{
                            vibrator.vibrate(3000);
                        }

                    }
                }, 5000);
            }
        }.start();

    }
}